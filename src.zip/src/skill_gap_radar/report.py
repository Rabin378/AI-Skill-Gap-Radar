from __future__ import annotations

from html import escape
from pathlib import Path

from .models import JobPosting, SkillRecommendation, SkillScore


def _bar(value: float) -> str:
    safe_value = max(0.0, min(100.0, value))
    return f'<span class="bar"><span style="width: {safe_value:.1f}%"></span></span>'


def build_html_report(
    jobs: list[JobPosting],
    skill_scores: list[SkillScore],
    gap_score: float,
    recommendations: list[SkillRecommendation],
    limit: int = 10,
) -> str:
    rows = []
    for score in skill_scores[:limit]:
        change_class = "up" if score.change_12m_pct >= 0 else "down"
        rows.append(
            "<tr>"
            f"<td>{escape(score.skill)}</td>"
            f"<td>{_bar(score.projected_value_score)} {score.projected_value_score:.1f}</td>"
            f"<td>{score.posting_count}</td>"
            f"<td>${score.avg_salary:,.0f}</td>"
            f'<td class="{change_class}">{score.change_12m_pct:+.0f}%</td>'
            "</tr>"
        )

    recommendation_cards = []
    for recommendation in recommendations:
        recommendation_cards.append(
            '<article class="recommendation">'
            f"<h3>{escape(recommendation.skill)}</h3>"
            f"<p>{escape(recommendation.reason)}</p>"
            f"<strong>Current level: {recommendation.current_level:.1f}/5</strong>"
            "</article>"
        )

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AI Skill Gap Radar</title>
  <style>
    :root {{
      --ink: #18202f;
      --muted: #657186;
      --line: #d9dee8;
      --panel: #ffffff;
      --bg: #f5f7fb;
      --accent: #2563eb;
      --accent-2: #10b981;
      --warn: #dc2626;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: var(--ink);
      background: var(--bg);
    }}
    main {{
      width: min(1120px, calc(100vw - 32px));
      margin: 0 auto;
      padding: 40px 0;
    }}
    header {{
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 24px;
      align-items: end;
      border-bottom: 1px solid var(--line);
      padding-bottom: 24px;
      margin-bottom: 24px;
    }}
    h1 {{ margin: 0 0 8px; font-size: 36px; letter-spacing: 0; }}
    h2 {{ margin: 0 0 16px; font-size: 20px; letter-spacing: 0; }}
    h3 {{ margin: 0 0 8px; font-size: 16px; letter-spacing: 0; }}
    p {{ color: var(--muted); line-height: 1.55; }}
    .score {{
      min-width: 180px;
      padding: 18px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--panel);
      text-align: center;
    }}
    .score strong {{ display: block; font-size: 36px; color: var(--accent); }}
    section {{
      margin-top: 24px;
      padding: 24px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--panel);
    }}
    table {{ width: 100%; border-collapse: collapse; }}
    th, td {{ padding: 13px 10px; border-bottom: 1px solid var(--line); text-align: left; }}
    th {{ color: var(--muted); font-size: 13px; font-weight: 700; }}
    .bar {{
      display: inline-block;
      width: min(240px, 38vw);
      height: 12px;
      margin-right: 10px;
      border-radius: 999px;
      background: #e7ebf3;
      vertical-align: middle;
      overflow: hidden;
    }}
    .bar span {{ display: block; height: 100%; background: linear-gradient(90deg, var(--accent), var(--accent-2)); }}
    .up {{ color: #047857; font-weight: 700; }}
    .down {{ color: var(--warn); font-weight: 700; }}
    .recommendations {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 14px;
    }}
    .recommendation {{
      min-height: 150px;
      padding: 16px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: #fbfcff;
    }}
    .recommendation p {{ margin: 0 0 12px; font-size: 14px; }}
    @media (max-width: 720px) {{
      header {{ grid-template-columns: 1fr; }}
      h1 {{ font-size: 30px; }}
      th:nth-child(3), td:nth-child(3) {{ display: none; }}
    }}
  </style>
</head>
<body>
  <main>
    <header>
      <div>
        <h1>AI Skill Gap Radar</h1>
        <p>Market signal summary from {len(jobs)} sample job postings, salary ranges, and technology trend indicators.</p>
      </div>
      <div class="score">
        <span>Skill Gap Score</span>
        <strong>{gap_score:.1f}%</strong>
      </div>
    </header>
    <section>
      <h2>Most Valuable Skills</h2>
      <table>
        <thead>
          <tr>
            <th>Skill</th>
            <th>Projected value</th>
            <th>Postings</th>
            <th>Average salary</th>
            <th>Trend</th>
          </tr>
        </thead>
        <tbody>
          {''.join(rows)}
        </tbody>
      </table>
    </section>
    <section>
      <h2>Recommended Next Skills</h2>
      <div class="recommendations">
        {''.join(recommendation_cards)}
      </div>
    </section>
  </main>
</body>
</html>
"""


def write_html_report(
    output_path: str | Path,
    jobs: list[JobPosting],
    skill_scores: list[SkillScore],
    gap_score: float,
    recommendations: list[SkillRecommendation],
    limit: int = 10,
) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        build_html_report(jobs, skill_scores, gap_score, recommendations, limit=limit),
        encoding="utf-8",
    )
    return path.resolve()

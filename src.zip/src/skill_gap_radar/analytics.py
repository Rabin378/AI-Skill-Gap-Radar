from __future__ import annotations

from collections import defaultdict
from statistics import mean

from .models import JobPosting, SkillRecommendation, SkillScore, TrendSignal


def _scale(value: float, minimum: float, maximum: float) -> float:
    if maximum == minimum:
        return 100.0
    return max(0.0, min(100.0, ((value - minimum) / (maximum - minimum)) * 100))


def _growth_score(trend_index: float, change_12m_pct: float) -> float:
    trend_component = max(0.0, min(100.0, trend_index))
    change_component = _scale(change_12m_pct, -10.0, 40.0)
    return (trend_component * 0.55) + (change_component * 0.45)


def build_skill_scores(
    jobs: list[JobPosting],
    trends: dict[str, TrendSignal],
    demand_weight: float = 0.45,
    salary_weight: float = 0.35,
    growth_weight: float = 0.20,
) -> list[SkillScore]:
    if not jobs:
        return []

    skill_to_salaries: dict[str, list[float]] = defaultdict(list)
    for job in jobs:
        for skill in set(job.skills):
            skill_to_salaries[skill].append(job.salary_midpoint)

    counts = {skill: len(salaries) for skill, salaries in skill_to_salaries.items()}
    avg_salaries = {skill: mean(salaries) for skill, salaries in skill_to_salaries.items()}
    max_count = max(counts.values())
    min_salary = min(avg_salaries.values())
    max_salary = max(avg_salaries.values())

    scores: list[SkillScore] = []
    for skill, posting_count in counts.items():
        avg_salary = avg_salaries[skill]
        trend = trends.get(skill)
        trend_index = trend.trend_index if trend else 50.0
        change_12m_pct = trend.change_12m_pct if trend else 0.0
        demand_score = (posting_count / max_count) * 100
        salary_score = _scale(avg_salary, min_salary, max_salary)
        growth_score = _growth_score(trend_index, change_12m_pct)
        value_score = (
            (demand_score * demand_weight)
            + (salary_score * salary_weight)
            + (growth_score * growth_weight)
        )
        projected_value_score = max(0.0, min(100.0, value_score * (1 + (change_12m_pct / 100))))
        scores.append(
            SkillScore(
                skill=skill,
                posting_count=posting_count,
                avg_salary=avg_salary,
                trend_index=trend_index,
                change_12m_pct=change_12m_pct,
                demand_score=demand_score,
                salary_score=salary_score,
                growth_score=growth_score,
                value_score=value_score,
                projected_value_score=projected_value_score,
            )
        )

    return sorted(scores, key=lambda score: score.projected_value_score, reverse=True)


def calculate_skill_gap_score(skill_scores: list[SkillScore], user_skills: dict[str, float]) -> float:
    total_market_value = sum(score.projected_value_score for score in skill_scores)
    if total_market_value == 0:
        return 0.0

    missing_value = 0.0
    for score in skill_scores:
        current_level = max(0.0, min(5.0, user_skills.get(score.skill, 0.0)))
        missing_ratio = 1 - (current_level / 5)
        missing_value += score.projected_value_score * missing_ratio

    return round((missing_value / total_market_value) * 100, 1)


def recommend_skills(
    skill_scores: list[SkillScore],
    user_skills: dict[str, float],
    limit: int = 5,
) -> list[SkillRecommendation]:
    recommendations: list[SkillRecommendation] = []
    for score in skill_scores:
        current_level = max(0.0, min(5.0, user_skills.get(score.skill, 0.0)))
        missing_ratio = 1 - (current_level / 5)
        gap_contribution = score.projected_value_score * missing_ratio
        if gap_contribution <= 0:
            continue

        reason = (
            f"{score.skill} appears in {score.posting_count} postings, has an average salary signal "
            f"of ${score.avg_salary:,.0f}, and is trending {score.change_12m_pct:+.0f}% over 12 months."
        )
        recommendations.append(
            SkillRecommendation(
                skill=score.skill,
                current_level=current_level,
                target_score=score.projected_value_score,
                gap_contribution=gap_contribution,
                reason=reason,
            )
        )

    return sorted(recommendations, key=lambda rec: rec.gap_contribution, reverse=True)[:limit]


def render_bar(value: float, width: int = 18) -> str:
    filled = round((value / 100) * width)
    return "█" * filled + "░" * (width - filled)

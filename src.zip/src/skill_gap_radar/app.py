from __future__ import annotations

import plotly.express as px
import streamlit as st

from skill_gap_radar.analytics import build_skill_scores, calculate_skill_gap_score, recommend_skills
from skill_gap_radar.data_loader import load_job_postings, load_trend_signals, load_user_skills, normalize_skill


@st.cache_data
def load_demo_data():
    jobs = load_job_postings()
    trends = load_trend_signals()
    user_skills = load_user_skills()
    return jobs, trends, user_skills


def normalize_skill_map(skills: dict[str, float]) -> dict[str, float]:
    normalized: dict[str, float] = {}
    for skill, level in skills.items():
        safe_skill = normalize_skill(str(skill))
        normalized[safe_skill] = max(0.0, min(5.0, float(level)))
    return normalized


def build_skill_radar_rows(skill_scores, limit: int):
    return [
        {
            "Skill": score.skill,
            "Projected Value": round(score.projected_value_score, 1),
            "Demand": round(score.demand_score, 1),
            "Salary": round(score.salary_score, 1),
            "Growth": round(score.growth_score, 1),
            "12M Change": score.change_12m_pct,
            "Average Salary": round(score.avg_salary),
            "Postings": score.posting_count,
        }
        for score in skill_scores[:limit]
    ]


def render_dashboard():
    st.set_page_config(page_title="AI Skill Gap Radar", layout="wide")

    jobs, trends, default_user_skills = load_demo_data()
    skill_scores = build_skill_scores(jobs, trends)
    normalized_defaults = normalize_skill_map(default_user_skills)

    st.title("AI Skill Gap Radar")
    st.caption("Find skills that are gaining market value, then compare them with your current skill profile.")

    if not jobs or not skill_scores:
        st.warning("No market data was loaded. Add job postings and trend signals to view the radar.")
        return

    with st.sidebar:
        st.header("Your Skills")
        user_skills: dict[str, float] = {}
        for score in skill_scores[:12]:
            default_value = normalized_defaults.get(score.skill, 0.0)
            user_skills[score.skill] = st.slider(
                score.skill,
                min_value=0.0,
                max_value=5.0,
                value=float(default_value),
                step=0.5,
            )
        top_n = st.slider("Skills to show", min_value=5, max_value=min(15, len(skill_scores)), value=min(10, len(skill_scores)))

    gap_score = calculate_skill_gap_score(skill_scores, user_skills)
    recommendations = recommend_skills(skill_scores, user_skills, limit=5)

    metric_cols = st.columns(4)
    metric_cols[0].metric("Job Postings", len(jobs))
    metric_cols[1].metric("Tracked Skills", len(skill_scores))
    metric_cols[2].metric("Skill Gap Score", f"{gap_score}%")
    metric_cols[3].metric("Top Recommendation", recommendations[0].skill if recommendations else "None")

    radar_rows = build_skill_radar_rows(skill_scores, top_n)
    left, right = st.columns([1.25, 1])

    with left:
        st.subheader("Skill Value Radar")
        fig = px.bar(
            radar_rows,
            x="Projected Value",
            y="Skill",
            orientation="h",
            color="12M Change",
            color_continuous_scale="RdYlGn",
            hover_data=["Demand", "Salary", "Growth", "Average Salary", "Postings"],
        )
        fig.update_layout(
            yaxis={"categoryorder": "total ascending"},
            height=460,
            margin=dict(l=10, r=10, t=10, b=10),
        )
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Recommended Next Skills")
        if not recommendations:
            st.info("Your current skills already cover the strongest market opportunities.")
        else:
            for recommendation in recommendations:
                st.progress(min(1.0, recommendation.gap_contribution / 100))
                st.markdown(f"**{recommendation.skill}**")
                st.write(recommendation.reason)

    st.subheader("Market Signals")
    st.dataframe(radar_rows, use_container_width=True, hide_index=True)


if __name__ == "__main__":
    render_dashboard()

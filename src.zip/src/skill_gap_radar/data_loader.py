from __future__ import annotations

import csv
from datetime import date
from pathlib import Path

from .models import JobPosting, TrendSignal


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA_DIR = PROJECT_ROOT / "data"


def normalize_skill(skill: str) -> str:
    aliases = {
        "generative ai": "GenAI",
        "gen ai": "GenAI",
        "genai": "GenAI",
        "large language models": "LLM",
        "llms": "LLM",
        "bi": "BI",
        "mlops": "MLOps",
        "dbt": "dbt",
        "apis": "APIs",
    }
    cleaned = " ".join(skill.strip().split())
    if not cleaned:
        return cleaned
    return aliases.get(cleaned.lower(), cleaned)


def split_skills(raw_skills: str) -> tuple[str, ...]:
    return tuple(normalize_skill(skill) for skill in raw_skills.split(";") if skill.strip())


def load_job_postings(path: str | Path = DEFAULT_DATA_DIR / "sample_job_postings.csv") -> list[JobPosting]:
    rows: list[JobPosting] = []
    with Path(path).open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append(
                JobPosting(
                    job_id=row["job_id"],
                    title=row["title"],
                    company=row["company"],
                    location=row["location"],
                    posted_date=date.fromisoformat(row["posted_date"]),
                    salary_min=float(row["salary_min"]),
                    salary_max=float(row["salary_max"]),
                    skills=split_skills(row["skills"]),
                )
            )
    return rows


def load_trend_signals(path: str | Path = DEFAULT_DATA_DIR / "technology_trends.csv") -> dict[str, TrendSignal]:
    signals: dict[str, TrendSignal] = {}
    with Path(path).open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            skill = normalize_skill(row["skill"])
            signals[skill] = TrendSignal(
                skill=skill,
                trend_index=float(row["trend_index"]),
                change_12m_pct=float(row["change_12m_pct"]),
                source_note=row["source_note"],
            )
    return signals


def load_user_skills(path: str | Path = DEFAULT_DATA_DIR / "user_skills.csv") -> dict[str, float]:
    skills: dict[str, float] = {}
    with Path(path).open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            skills[normalize_skill(row["skill"])] = max(0.0, min(5.0, float(row["level"])))
    return skills

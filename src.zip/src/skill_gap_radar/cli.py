from __future__ import annotations

import argparse
from pathlib import Path

from .analytics import build_skill_scores, calculate_skill_gap_score, recommend_skills, render_bar
from .data_loader import DEFAULT_DATA_DIR, load_job_postings, load_trend_signals, load_user_skills
from .report import write_html_report


def _print_analysis(args: argparse.Namespace) -> None:
    jobs = load_job_postings(args.jobs)
    trends = load_trend_signals(args.trends)
    user_skills = load_user_skills(args.user)
    skill_scores = build_skill_scores(jobs, trends)
    gap_score = calculate_skill_gap_score(skill_scores, user_skills)
    recommendations = recommend_skills(skill_scores, user_skills, limit=args.top)

    print("\nDATA SCIENCE SKILL RADAR")
    print("=" * 28)
    for score in skill_scores[: args.top]:
        print(f"{score.skill:<18} {render_bar(score.projected_value_score)} {score.projected_value_score:5.1f}")

    print("\nTrend")
    print("-" * 28)
    for score in skill_scores[: args.top]:
        arrow = "↑" if score.change_12m_pct >= 0 else "↓"
        print(f"{score.skill:<18} {arrow} {abs(score.change_12m_pct):.0f}%")

    print(f"\nSkill Gap Score: {gap_score}%")
    print("\nRecommended Next Skills")
    print("-" * 28)
    for index, recommendation in enumerate(recommendations, start=1):
        print(
            f"{index}. {recommendation.skill} "
            f"(current {recommendation.current_level:.1f}/5, opportunity {recommendation.gap_contribution:.1f})"
        )
        print(f"   {recommendation.reason}")


def _write_report(args: argparse.Namespace) -> None:
    jobs = load_job_postings(args.jobs)
    trends = load_trend_signals(args.trends)
    user_skills = load_user_skills(args.user)
    skill_scores = build_skill_scores(jobs, trends)
    gap_score = calculate_skill_gap_score(skill_scores, user_skills)
    recommendations = recommend_skills(skill_scores, user_skills, limit=args.top)
    output_path = write_html_report(args.output, jobs, skill_scores, gap_score, recommendations, limit=args.top)
    print(f"Wrote report: {output_path}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Analyze market demand and recommend valuable skills to learn.")
    subparsers = parser.add_subparsers(dest="command")

    analyze = subparsers.add_parser("analyze", help="Run the skill radar analysis.")
    analyze.add_argument("--jobs", type=Path, default=DEFAULT_DATA_DIR / "sample_job_postings.csv")
    analyze.add_argument("--trends", type=Path, default=DEFAULT_DATA_DIR / "technology_trends.csv")
    analyze.add_argument("--user", type=Path, default=DEFAULT_DATA_DIR / "user_skills.csv")
    analyze.add_argument("--top", type=int, default=8)
    analyze.set_defaults(func=_print_analysis)

    report = subparsers.add_parser("report", help="Write a standalone HTML report.")
    report.add_argument("--jobs", type=Path, default=DEFAULT_DATA_DIR / "sample_job_postings.csv")
    report.add_argument("--trends", type=Path, default=DEFAULT_DATA_DIR / "technology_trends.csv")
    report.add_argument("--user", type=Path, default=DEFAULT_DATA_DIR / "user_skills.csv")
    report.add_argument("--output", type=Path, default=Path("outputs") / "skill_gap_radar_report.html")
    report.add_argument("--top", type=int, default=10)
    report.set_defaults(func=_write_report)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if not args.command:
        args = parser.parse_args(["analyze"])
    args.func(args)


if __name__ == "__main__":
    main()

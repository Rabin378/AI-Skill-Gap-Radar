from datetime import date

from skill_gap_radar.analytics import build_skill_scores, calculate_skill_gap_score, recommend_skills
from skill_gap_radar.models import JobPosting, TrendSignal


def test_skill_scores_rank_high_growth_high_salary_skill():
    jobs = [
        JobPosting("1", "AI Engineer", "A", "Remote", date(2026, 1, 1), 150000, 210000, ("Python", "GenAI")),
        JobPosting("2", "Analyst", "B", "Remote", date(2026, 1, 2), 70000, 90000, ("Excel", "SQL")),
        JobPosting("3", "AI Analyst", "C", "Remote", date(2026, 1, 3), 120000, 170000, ("GenAI", "SQL")),
    ]
    trends = {
        "GenAI": TrendSignal("GenAI", 95, 35, "test"),
        "Excel": TrendSignal("Excel", 45, -4, "test"),
        "SQL": TrendSignal("SQL", 80, 10, "test"),
        "Python": TrendSignal("Python", 88, 14, "test"),
    }

    scores = build_skill_scores(jobs, trends)

    assert scores[0].skill == "GenAI"
    assert scores[0].projected_value_score > scores[-1].projected_value_score


def test_gap_score_drops_when_user_has_more_skills():
    jobs = [
        JobPosting("1", "Data Scientist", "A", "Remote", date(2026, 1, 1), 100000, 140000, ("Python", "SQL")),
        JobPosting("2", "ML Engineer", "B", "Remote", date(2026, 1, 2), 150000, 190000, ("Python", "MLOps")),
    ]
    trends = {"Python": TrendSignal("Python", 88, 14, "test")}
    scores = build_skill_scores(jobs, trends)

    beginner_gap = calculate_skill_gap_score(scores, {"Python": 0, "SQL": 0, "MLOps": 0})
    advanced_gap = calculate_skill_gap_score(scores, {"Python": 5, "SQL": 5, "MLOps": 5})

    assert beginner_gap > advanced_gap
    assert advanced_gap == 0


def test_recommendations_prioritize_missing_high_value_skills():
    jobs = [
        JobPosting("1", "AI Engineer", "A", "Remote", date(2026, 1, 1), 150000, 210000, ("GenAI", "Python")),
        JobPosting("2", "AI Engineer", "B", "Remote", date(2026, 1, 2), 150000, 210000, ("GenAI", "SQL")),
    ]
    trends = {"GenAI": TrendSignal("GenAI", 95, 35, "test")}
    scores = build_skill_scores(jobs, trends)

    recommendations = recommend_skills(scores, {"Python": 5, "SQL": 5, "GenAI": 0}, limit=1)

    assert recommendations[0].skill == "GenAI"
